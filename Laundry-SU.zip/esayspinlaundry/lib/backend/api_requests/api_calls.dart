import 'dart:convert';
import 'dart:typed_data';
import '../schema/structs/index.dart';

import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class PaymentCall {
  static Future<ApiCallResponse> call({
    String? paymentSessionId = '',
    String? channel = '',
    String? upiId = '',
    int? upiExpiryMinutes,
  }) async {
    final ffApiRequestBody = '''
{
  "payment_method": {
    "upi": {
      "channel": "${escapeStringForJson(channel)}",
      "upi_id": "${escapeStringForJson(upiId)}",
      "upi_expiry_minutes": ${upiExpiryMinutes}
    }
  },
  "payment_session_id": "${escapeStringForJson(paymentSessionId)}"
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'Payment',
      apiUrl: 'https://sandbox.cashfree.com/pg/orders/sessions',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'x-api-version': '2022-09-01',
        'x-client-id': 'TEST10482247c61b6610ce4e05ab64d474228401',
        'x-client-secret':
            'cfsk_ma_test_d7d7d76d2115c018b23c48299ab42019_0efed485',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class PaymentGatewayCopyCall {
  static Future<ApiCallResponse> call({
    double? orderAmount,
    String? orderCurrency = '',
    String? customerId = '',
    String? customerEmail = '',
    String? customerPhone = '',
  }) async {
    final ffApiRequestBody = '''
{
  "order_amount": ${orderAmount},
  "order_currency": "${escapeStringForJson(orderCurrency)}",
  "customer_details": {
    "customer_id": "${escapeStringForJson(customerId)}",
    "customer_phone": "${escapeStringForJson(customerPhone)}",
    "customer_email": "${escapeStringForJson(customerEmail)}"
  }
}''';
    return ApiManager.instance.makeApiCall(
      callName: 'PaymentGateway Copy',
      apiUrl: 'https://sandbox.cashfree.com/pg/orders',
      callType: ApiCallType.POST,
      headers: {
        'Content-Type': 'application/json',
        'x-api-version': '2022-09-01',
        'x-client-id': 'TEST10482247c61b6610ce4e05ab64d474228401',
        'x-client-secret':
            'cfsk_ma_test_d7d7d76d2115c018b23c48299ab42019_0efed485',
      },
      params: {},
      body: ffApiRequestBody,
      bodyType: BodyType.JSON,
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}

String? escapeStringForJson(String? input) {
  if (input == null) {
    return null;
  }
  return input
      .replaceAll('\\', '\\\\')
      .replaceAll('"', '\\"')
      .replaceAll('\n', '\\n')
      .replaceAll('\t', '\\t');
}
