import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SteamironRecord extends FirestoreRecord {
  SteamironRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "quantity" field.
  int? _quantity;
  int get quantity => _quantity ?? 0;
  bool hasQuantity() => _quantity != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  // "cat" field.
  String? _cat;
  String get cat => _cat ?? '';
  bool hasCat() => _cat != null;

  // "uid" field.
  DocumentReference? _uid;
  DocumentReference? get uid => _uid;
  bool hasUid() => _uid != null;

  // "ServiceType" field.
  String? _serviceType;
  String get serviceType => _serviceType ?? '';
  bool hasServiceType() => _serviceType != null;

  // "productid" field.
  String? _productid;
  String get productid => _productid ?? '';
  bool hasProductid() => _productid != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _quantity = castToType<int>(snapshotData['quantity']);
    _price = castToType<double>(snapshotData['price']);
    _cat = snapshotData['cat'] as String?;
    _uid = snapshotData['uid'] as DocumentReference?;
    _serviceType = snapshotData['ServiceType'] as String?;
    _productid = snapshotData['productid'] as String?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('Steamiron');

  static Stream<SteamironRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SteamironRecord.fromSnapshot(s));

  static Future<SteamironRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SteamironRecord.fromSnapshot(s));

  static SteamironRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SteamironRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SteamironRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SteamironRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SteamironRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SteamironRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSteamironRecordData({
  String? name,
  int? quantity,
  double? price,
  String? cat,
  DocumentReference? uid,
  String? serviceType,
  String? productid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'quantity': quantity,
      'price': price,
      'cat': cat,
      'uid': uid,
      'ServiceType': serviceType,
      'productid': productid,
    }.withoutNulls,
  );

  return firestoreData;
}

class SteamironRecordDocumentEquality implements Equality<SteamironRecord> {
  const SteamironRecordDocumentEquality();

  @override
  bool equals(SteamironRecord? e1, SteamironRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.quantity == e2?.quantity &&
        e1?.price == e2?.price &&
        e1?.cat == e2?.cat &&
        e1?.uid == e2?.uid &&
        e1?.serviceType == e2?.serviceType &&
        e1?.productid == e2?.productid;
  }

  @override
  int hash(SteamironRecord? e) => const ListEquality().hash([
        e?.name,
        e?.quantity,
        e?.price,
        e?.cat,
        e?.uid,
        e?.serviceType,
        e?.productid
      ]);

  @override
  bool isValidKey(Object? o) => o is SteamironRecord;
}
