import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UserordersRecord extends FirestoreRecord {
  UserordersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "uid" field.
  DocumentReference? _uid;
  DocumentReference? get uid => _uid;
  bool hasUid() => _uid != null;

  // "orderID" field.
  String? _orderID;
  String get orderID => _orderID ?? '';
  bool hasOrderID() => _orderID != null;

  // "pickupref" field.
  DocumentReference? _pickupref;
  DocumentReference? get pickupref => _pickupref;
  bool hasPickupref() => _pickupref != null;

  // "orderTime" field.
  DateTime? _orderTime;
  DateTime? get orderTime => _orderTime;
  bool hasOrderTime() => _orderTime != null;

  void _initializeFields() {
    _uid = snapshotData['uid'] as DocumentReference?;
    _orderID = snapshotData['orderID'] as String?;
    _pickupref = snapshotData['pickupref'] as DocumentReference?;
    _orderTime = snapshotData['orderTime'] as DateTime?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('userorders');

  static Stream<UserordersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UserordersRecord.fromSnapshot(s));

  static Future<UserordersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UserordersRecord.fromSnapshot(s));

  static UserordersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      UserordersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UserordersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UserordersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UserordersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UserordersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUserordersRecordData({
  DocumentReference? uid,
  String? orderID,
  DocumentReference? pickupref,
  DateTime? orderTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'uid': uid,
      'orderID': orderID,
      'pickupref': pickupref,
      'orderTime': orderTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class UserordersRecordDocumentEquality implements Equality<UserordersRecord> {
  const UserordersRecordDocumentEquality();

  @override
  bool equals(UserordersRecord? e1, UserordersRecord? e2) {
    return e1?.uid == e2?.uid &&
        e1?.orderID == e2?.orderID &&
        e1?.pickupref == e2?.pickupref &&
        e1?.orderTime == e2?.orderTime;
  }

  @override
  int hash(UserordersRecord? e) => const ListEquality()
      .hash([e?.uid, e?.orderID, e?.pickupref, e?.orderTime]);

  @override
  bool isValidKey(Object? o) => o is UserordersRecord;
}
