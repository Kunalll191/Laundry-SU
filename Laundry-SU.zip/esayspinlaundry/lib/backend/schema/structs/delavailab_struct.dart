// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DelavailabStruct extends FFFirebaseStruct {
  DelavailabStruct({
    DateTime? tweleve,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _tweleve = tweleve,
        super(firestoreUtilData);

  // "tweleve" field.
  DateTime? _tweleve;
  DateTime? get tweleve => _tweleve;
  set tweleve(DateTime? val) => _tweleve = val;

  bool hasTweleve() => _tweleve != null;

  static DelavailabStruct fromMap(Map<String, dynamic> data) =>
      DelavailabStruct(
        tweleve: data['tweleve'] as DateTime?,
      );

  static DelavailabStruct? maybeFromMap(dynamic data) => data is Map
      ? DelavailabStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'tweleve': _tweleve,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'tweleve': serializeParam(
          _tweleve,
          ParamType.DateTime,
        ),
      }.withoutNulls;

  static DelavailabStruct fromSerializableMap(Map<String, dynamic> data) =>
      DelavailabStruct(
        tweleve: deserializeParam(
          data['tweleve'],
          ParamType.DateTime,
          false,
        ),
      );

  @override
  String toString() => 'DelavailabStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is DelavailabStruct && tweleve == other.tweleve;
  }

  @override
  int get hashCode => const ListEquality().hash([tweleve]);
}

DelavailabStruct createDelavailabStruct({
  DateTime? tweleve,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    DelavailabStruct(
      tweleve: tweleve,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

DelavailabStruct? updateDelavailabStruct(
  DelavailabStruct? delavailab, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    delavailab
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDelavailabStructData(
  Map<String, dynamic> firestoreData,
  DelavailabStruct? delavailab,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (delavailab == null) {
    return;
  }
  if (delavailab.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && delavailab.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final delavailabData = getDelavailabFirestoreData(delavailab, forFieldValue);
  final nestedData = delavailabData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = delavailab.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDelavailabFirestoreData(
  DelavailabStruct? delavailab, [
  bool forFieldValue = false,
]) {
  if (delavailab == null) {
    return {};
  }
  final firestoreData = mapToFirestore(delavailab.toMap());

  // Add any Firestore field values
  delavailab.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDelavailabListFirestoreData(
  List<DelavailabStruct>? delavailabs,
) =>
    delavailabs?.map((e) => getDelavailabFirestoreData(e, true)).toList() ?? [];
