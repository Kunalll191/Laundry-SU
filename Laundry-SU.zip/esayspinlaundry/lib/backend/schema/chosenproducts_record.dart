import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChosenproductsRecord extends FirestoreRecord {
  ChosenproductsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "price" field.
  double? _price;
  double get price => _price ?? 0.0;
  bool hasPrice() => _price != null;

  // "quantity" field.
  int? _quantity;
  int get quantity => _quantity ?? 0;
  bool hasQuantity() => _quantity != null;

  // "cat" field.
  String? _cat;
  String get cat => _cat ?? '';
  bool hasCat() => _cat != null;

  // "type" field.
  String? _type;
  String get type => _type ?? '';
  bool hasType() => _type != null;

  // "productid" field.
  String? _productid;
  String get productid => _productid ?? '';
  bool hasProductid() => _productid != null;

  // "userref" field.
  DocumentReference? _userref;
  DocumentReference? get userref => _userref;
  bool hasUserref() => _userref != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _price = castToType<double>(snapshotData['price']);
    _quantity = castToType<int>(snapshotData['quantity']);
    _cat = snapshotData['cat'] as String?;
    _type = snapshotData['type'] as String?;
    _productid = snapshotData['productid'] as String?;
    _userref = snapshotData['userref'] as DocumentReference?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('chosenproducts');

  static Stream<ChosenproductsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChosenproductsRecord.fromSnapshot(s));

  static Future<ChosenproductsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChosenproductsRecord.fromSnapshot(s));

  static ChosenproductsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ChosenproductsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChosenproductsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChosenproductsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChosenproductsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChosenproductsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChosenproductsRecordData({
  String? name,
  double? price,
  int? quantity,
  String? cat,
  String? type,
  String? productid,
  DocumentReference? userref,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'price': price,
      'quantity': quantity,
      'cat': cat,
      'type': type,
      'productid': productid,
      'userref': userref,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChosenproductsRecordDocumentEquality
    implements Equality<ChosenproductsRecord> {
  const ChosenproductsRecordDocumentEquality();

  @override
  bool equals(ChosenproductsRecord? e1, ChosenproductsRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.price == e2?.price &&
        e1?.quantity == e2?.quantity &&
        e1?.cat == e2?.cat &&
        e1?.type == e2?.type &&
        e1?.productid == e2?.productid &&
        e1?.userref == e2?.userref;
  }

  @override
  int hash(ChosenproductsRecord? e) => const ListEquality().hash([
        e?.name,
        e?.price,
        e?.quantity,
        e?.cat,
        e?.type,
        e?.productid,
        e?.userref
      ]);

  @override
  bool isValidKey(Object? o) => o is ChosenproductsRecord;
}
