import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DeliveryScheduleRecord extends FirestoreRecord {
  DeliveryScheduleRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userref" field.
  DocumentReference? _userref;
  DocumentReference? get userref => _userref;
  bool hasUserref() => _userref != null;

  // "orderref" field.
  DocumentReference? _orderref;
  DocumentReference? get orderref => _orderref;
  bool hasOrderref() => _orderref != null;

  // "availability" field.
  List<AvailabilityStruct>? _availability;
  List<AvailabilityStruct> get availability => _availability ?? const [];
  bool hasAvailability() => _availability != null;

  // "deliveryfilter" field.
  DelavailabStruct? _deliveryfilter;
  DelavailabStruct get deliveryfilter => _deliveryfilter ?? DelavailabStruct();
  bool hasDeliveryfilter() => _deliveryfilter != null;

  void _initializeFields() {
    _userref = snapshotData['userref'] as DocumentReference?;
    _orderref = snapshotData['orderref'] as DocumentReference?;
    _availability = getStructList(
      snapshotData['availability'],
      AvailabilityStruct.fromMap,
    );
    _deliveryfilter = snapshotData['deliveryfilter'] is DelavailabStruct
        ? snapshotData['deliveryfilter']
        : DelavailabStruct.maybeFromMap(snapshotData['deliveryfilter']);
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('DeliverySchedule');

  static Stream<DeliveryScheduleRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DeliveryScheduleRecord.fromSnapshot(s));

  static Future<DeliveryScheduleRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => DeliveryScheduleRecord.fromSnapshot(s));

  static DeliveryScheduleRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DeliveryScheduleRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DeliveryScheduleRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DeliveryScheduleRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DeliveryScheduleRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DeliveryScheduleRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDeliveryScheduleRecordData({
  DocumentReference? userref,
  DocumentReference? orderref,
  DelavailabStruct? deliveryfilter,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userref': userref,
      'orderref': orderref,
      'deliveryfilter': DelavailabStruct().toMap(),
    }.withoutNulls,
  );

  // Handle nested data for "deliveryfilter" field.
  addDelavailabStructData(firestoreData, deliveryfilter, 'deliveryfilter');

  return firestoreData;
}

class DeliveryScheduleRecordDocumentEquality
    implements Equality<DeliveryScheduleRecord> {
  const DeliveryScheduleRecordDocumentEquality();

  @override
  bool equals(DeliveryScheduleRecord? e1, DeliveryScheduleRecord? e2) {
    const listEquality = ListEquality();
    return e1?.userref == e2?.userref &&
        e1?.orderref == e2?.orderref &&
        listEquality.equals(e1?.availability, e2?.availability) &&
        e1?.deliveryfilter == e2?.deliveryfilter;
  }

  @override
  int hash(DeliveryScheduleRecord? e) => const ListEquality()
      .hash([e?.userref, e?.orderref, e?.availability, e?.deliveryfilter]);

  @override
  bool isValidKey(Object? o) => o is DeliveryScheduleRecord;
}
