import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrdersRecord extends FirestoreRecord {
  OrdersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "orderid" field.
  String? _orderid;
  String get orderid => _orderid ?? '';
  bool hasOrderid() => _orderid != null;

  // "totalamount" field.
  double? _totalamount;
  double get totalamount => _totalamount ?? 0.0;
  bool hasTotalamount() => _totalamount != null;

  // "paymentstatus" field.
  String? _paymentstatus;
  String get paymentstatus => _paymentstatus ?? '';
  bool hasPaymentstatus() => _paymentstatus != null;

  // "pickuploc" field.
  List<LatLng>? _pickuploc;
  List<LatLng> get pickuploc => _pickuploc ?? const [];
  bool hasPickuploc() => _pickuploc != null;

  // "deliverloc" field.
  List<LatLng>? _deliverloc;
  List<LatLng> get deliverloc => _deliverloc ?? const [];
  bool hasDeliverloc() => _deliverloc != null;

  // "TotalItems" field.
  int? _totalItems;
  int get totalItems => _totalItems ?? 0;
  bool hasTotalItems() => _totalItems != null;

  // "DeliveryTime" field.
  DateTime? _deliveryTime;
  DateTime? get deliveryTime => _deliveryTime;
  bool hasDeliveryTime() => _deliveryTime != null;

  // "PickupTime" field.
  String? _pickupTime;
  String get pickupTime => _pickupTime ?? '';
  bool hasPickupTime() => _pickupTime != null;

  // "cont" field.
  String? _cont;
  String get cont => _cont ?? '';
  bool hasCont() => _cont != null;

  void _initializeFields() {
    _orderid = snapshotData['orderid'] as String?;
    _totalamount = castToType<double>(snapshotData['totalamount']);
    _paymentstatus = snapshotData['paymentstatus'] as String?;
    _pickuploc = getDataList(snapshotData['pickuploc']);
    _deliverloc = getDataList(snapshotData['deliverloc']);
    _totalItems = castToType<int>(snapshotData['TotalItems']);
    _deliveryTime = snapshotData['DeliveryTime'] as DateTime?;
    _pickupTime = snapshotData['PickupTime'] as String?;
    _cont = snapshotData['cont'] as String?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('orders');

  static Stream<OrdersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrdersRecord.fromSnapshot(s));

  static Future<OrdersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrdersRecord.fromSnapshot(s));

  static OrdersRecord fromSnapshot(DocumentSnapshot snapshot) => OrdersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrdersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrdersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrdersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrdersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrdersRecordData({
  String? orderid,
  double? totalamount,
  String? paymentstatus,
  int? totalItems,
  DateTime? deliveryTime,
  String? pickupTime,
  String? cont,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'orderid': orderid,
      'totalamount': totalamount,
      'paymentstatus': paymentstatus,
      'TotalItems': totalItems,
      'DeliveryTime': deliveryTime,
      'PickupTime': pickupTime,
      'cont': cont,
    }.withoutNulls,
  );

  return firestoreData;
}

class OrdersRecordDocumentEquality implements Equality<OrdersRecord> {
  const OrdersRecordDocumentEquality();

  @override
  bool equals(OrdersRecord? e1, OrdersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.orderid == e2?.orderid &&
        e1?.totalamount == e2?.totalamount &&
        e1?.paymentstatus == e2?.paymentstatus &&
        listEquality.equals(e1?.pickuploc, e2?.pickuploc) &&
        listEquality.equals(e1?.deliverloc, e2?.deliverloc) &&
        e1?.totalItems == e2?.totalItems &&
        e1?.deliveryTime == e2?.deliveryTime &&
        e1?.pickupTime == e2?.pickupTime &&
        e1?.cont == e2?.cont;
  }

  @override
  int hash(OrdersRecord? e) => const ListEquality().hash([
        e?.orderid,
        e?.totalamount,
        e?.paymentstatus,
        e?.pickuploc,
        e?.deliverloc,
        e?.totalItems,
        e?.deliveryTime,
        e?.pickupTime,
        e?.cont
      ]);

  @override
  bool isValidKey(Object? o) => o is OrdersRecord;
}
