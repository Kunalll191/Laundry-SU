import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PickupScheduleRecord extends FirestoreRecord {
  PickupScheduleRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userref" field.
  DocumentReference? _userref;
  DocumentReference? get userref => _userref;
  bool hasUserref() => _userref != null;

  // "orderref" field.
  DocumentReference? _orderref;
  DocumentReference? get orderref => _orderref;
  bool hasOrderref() => _orderref != null;

  // "availability" field.
  List<AvailabilityStruct>? _availability;
  List<AvailabilityStruct> get availability => _availability ?? const [];
  bool hasAvailability() => _availability != null;

  // "pickedslot" field.
  DateTime? _pickedslot;
  DateTime? get pickedslot => _pickedslot;
  bool hasPickedslot() => _pickedslot != null;

  void _initializeFields() {
    _userref = snapshotData['userref'] as DocumentReference?;
    _orderref = snapshotData['orderref'] as DocumentReference?;
    _availability = getStructList(
      snapshotData['availability'],
      AvailabilityStruct.fromMap,
    );
    _pickedslot = snapshotData['pickedslot'] as DateTime?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('PickupSchedule');

  static Stream<PickupScheduleRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PickupScheduleRecord.fromSnapshot(s));

  static Future<PickupScheduleRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PickupScheduleRecord.fromSnapshot(s));

  static PickupScheduleRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PickupScheduleRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PickupScheduleRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PickupScheduleRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PickupScheduleRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PickupScheduleRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPickupScheduleRecordData({
  DocumentReference? userref,
  DocumentReference? orderref,
  DateTime? pickedslot,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userref': userref,
      'orderref': orderref,
      'pickedslot': pickedslot,
    }.withoutNulls,
  );

  return firestoreData;
}

class PickupScheduleRecordDocumentEquality
    implements Equality<PickupScheduleRecord> {
  const PickupScheduleRecordDocumentEquality();

  @override
  bool equals(PickupScheduleRecord? e1, PickupScheduleRecord? e2) {
    const listEquality = ListEquality();
    return e1?.userref == e2?.userref &&
        e1?.orderref == e2?.orderref &&
        listEquality.equals(e1?.availability, e2?.availability) &&
        e1?.pickedslot == e2?.pickedslot;
  }

  @override
  int hash(PickupScheduleRecord? e) => const ListEquality()
      .hash([e?.userref, e?.orderref, e?.availability, e?.pickedslot]);

  @override
  bool isValidKey(Object? o) => o is PickupScheduleRecord;
}
