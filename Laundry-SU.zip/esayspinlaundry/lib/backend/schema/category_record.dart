import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CategoryRecord extends FirestoreRecord {
  CategoryRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "mens" field.
  bool? _mens;
  bool get mens => _mens ?? false;
  bool hasMens() => _mens != null;

  // "women" field.
  bool? _women;
  bool get women => _women ?? false;
  bool hasWomen() => _women != null;

  // "household" field.
  bool? _household;
  bool get household => _household ?? false;
  bool hasHousehold() => _household != null;

  // "cartref" field.
  DocumentReference? _cartref;
  DocumentReference? get cartref => _cartref;
  bool hasCartref() => _cartref != null;

  void _initializeFields() {
    _mens = snapshotData['mens'] as bool?;
    _women = snapshotData['women'] as bool?;
    _household = snapshotData['household'] as bool?;
    _cartref = snapshotData['cartref'] as DocumentReference?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('category');

  static Stream<CategoryRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CategoryRecord.fromSnapshot(s));

  static Future<CategoryRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CategoryRecord.fromSnapshot(s));

  static CategoryRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CategoryRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CategoryRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CategoryRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CategoryRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CategoryRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCategoryRecordData({
  bool? mens,
  bool? women,
  bool? household,
  DocumentReference? cartref,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'mens': mens,
      'women': women,
      'household': household,
      'cartref': cartref,
    }.withoutNulls,
  );

  return firestoreData;
}

class CategoryRecordDocumentEquality implements Equality<CategoryRecord> {
  const CategoryRecordDocumentEquality();

  @override
  bool equals(CategoryRecord? e1, CategoryRecord? e2) {
    return e1?.mens == e2?.mens &&
        e1?.women == e2?.women &&
        e1?.household == e2?.household &&
        e1?.cartref == e2?.cartref;
  }

  @override
  int hash(CategoryRecord? e) =>
      const ListEquality().hash([e?.mens, e?.women, e?.household, e?.cartref]);

  @override
  bool isValidKey(Object? o) => o is CategoryRecord;
}
