import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _orderedproducts = prefs
              .getStringList('ff_orderedproducts')
              ?.map((path) => path.ref)
              .toList() ??
          _orderedproducts;
    });
    _safeInit(() {
      _ordersummary =
          prefs.getStringList('ff_ordersummary')?.map(double.parse).toList() ??
              _ordersummary;
    });
    _safeInit(() {
      _totalPrice = prefs.getDouble('ff_totalPrice') ?? _totalPrice;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  List<DocumentReference> _orderedproducts = [];
  List<DocumentReference> get orderedproducts => _orderedproducts;
  set orderedproducts(List<DocumentReference> value) {
    _orderedproducts = value;
    prefs.setStringList(
        'ff_orderedproducts', value.map((x) => x.path).toList());
  }

  void addToOrderedproducts(DocumentReference value) {
    orderedproducts.add(value);
    prefs.setStringList(
        'ff_orderedproducts', _orderedproducts.map((x) => x.path).toList());
  }

  void removeFromOrderedproducts(DocumentReference value) {
    orderedproducts.remove(value);
    prefs.setStringList(
        'ff_orderedproducts', _orderedproducts.map((x) => x.path).toList());
  }

  void removeAtIndexFromOrderedproducts(int index) {
    orderedproducts.removeAt(index);
    prefs.setStringList(
        'ff_orderedproducts', _orderedproducts.map((x) => x.path).toList());
  }

  void updateOrderedproductsAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    orderedproducts[index] = updateFn(_orderedproducts[index]);
    prefs.setStringList(
        'ff_orderedproducts', _orderedproducts.map((x) => x.path).toList());
  }

  void insertAtIndexInOrderedproducts(int index, DocumentReference value) {
    orderedproducts.insert(index, value);
    prefs.setStringList(
        'ff_orderedproducts', _orderedproducts.map((x) => x.path).toList());
  }

  List<double> _ordersummary = [];
  List<double> get ordersummary => _ordersummary;
  set ordersummary(List<double> value) {
    _ordersummary = value;
    prefs.setStringList(
        'ff_ordersummary', value.map((x) => x.toString()).toList());
  }

  void addToOrdersummary(double value) {
    ordersummary.add(value);
    prefs.setStringList(
        'ff_ordersummary', _ordersummary.map((x) => x.toString()).toList());
  }

  void removeFromOrdersummary(double value) {
    ordersummary.remove(value);
    prefs.setStringList(
        'ff_ordersummary', _ordersummary.map((x) => x.toString()).toList());
  }

  void removeAtIndexFromOrdersummary(int index) {
    ordersummary.removeAt(index);
    prefs.setStringList(
        'ff_ordersummary', _ordersummary.map((x) => x.toString()).toList());
  }

  void updateOrdersummaryAtIndex(
    int index,
    double Function(double) updateFn,
  ) {
    ordersummary[index] = updateFn(_ordersummary[index]);
    prefs.setStringList(
        'ff_ordersummary', _ordersummary.map((x) => x.toString()).toList());
  }

  void insertAtIndexInOrdersummary(int index, double value) {
    ordersummary.insert(index, value);
    prefs.setStringList(
        'ff_ordersummary', _ordersummary.map((x) => x.toString()).toList());
  }

  double _totalPrice = 0.0;
  double get totalPrice => _totalPrice;
  set totalPrice(double value) {
    _totalPrice = value;
    prefs.setDouble('ff_totalPrice', value);
  }

  List<AvailabilityStruct> _availability = [];
  List<AvailabilityStruct> get availability => _availability;
  set availability(List<AvailabilityStruct> value) {
    _availability = value;
  }

  void addToAvailability(AvailabilityStruct value) {
    availability.add(value);
  }

  void removeFromAvailability(AvailabilityStruct value) {
    availability.remove(value);
  }

  void removeAtIndexFromAvailability(int index) {
    availability.removeAt(index);
  }

  void updateAvailabilityAtIndex(
    int index,
    AvailabilityStruct Function(AvailabilityStruct) updateFn,
  ) {
    availability[index] = updateFn(_availability[index]);
  }

  void insertAtIndexInAvailability(int index, AvailabilityStruct value) {
    availability.insert(index, value);
  }

  String _filter = '';
  String get filter => _filter;
  set filter(String value) {
    _filter = value;
  }

  int _totalQuantity = 0;
  int get totalQuantity => _totalQuantity;
  set totalQuantity(int value) {
    _totalQuantity = value;
  }

  int _totalitemsdecrement = 0;
  int get totalitemsdecrement => _totalitemsdecrement;
  set totalitemsdecrement(int value) {
    _totalitemsdecrement = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
