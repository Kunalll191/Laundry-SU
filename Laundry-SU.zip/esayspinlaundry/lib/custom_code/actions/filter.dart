// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future filter() async {
  // custom action code for filtering the delivery slots when the user selects a pickup slot the delivery slots shown should be of atleast after 8 hours and if the the selected pickup slot is after 12:00 PM the available delivery should be next day 9:00 AM

  // Get the selected pickup slot
  DateTime selectedPickupSlot =
      DateTime.parse("2022-01-01 14:00:00"); // Example pickup slot

  // Calculate the minimum delivery time based on the selected pickup slot
  DateTime minDeliveryTime;
  if (selectedPickupSlot.hour >= 12) {
    // If pickup slot is after 12:00 PM, set minimum delivery time to next day 9:00 AM
    minDeliveryTime = DateTime(selectedPickupSlot.year,
        selectedPickupSlot.month, selectedPickupSlot.day + 1, 9, 0, 0);
  } else {
    // If pickup slot is before 12:00 PM, set minimum delivery time to at least 8 hours after pickup slot
    minDeliveryTime = selectedPickupSlot.add(Duration(hours: 8));
  }

  // Filter the delivery slots based on the minimum delivery time
  List<DateTime> deliverySlots = [
    DateTime.parse("2022-01-01 10:00:00"),
    DateTime.parse("2022-01-01 12:00:00"),
    DateTime.parse("2022-01-02 09:00:00"),
    DateTime.parse("2022-01-02 11:00:00"),
    DateTime.parse("2022-01-02 13:00:00"),
  ]; // Example delivery slots

  List<DateTime> filteredDeliverySlots =
      deliverySlots.where((slot) => slot.isAfter(minDeliveryTime)).toList();

  // Return the filtered delivery slots
  return filteredDeliverySlots;
}
