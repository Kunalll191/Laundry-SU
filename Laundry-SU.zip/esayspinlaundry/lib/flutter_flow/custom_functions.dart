import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

double increment(
  double price,
  double count,
) {
  return price * count;
}

double totalPrice(
  double price,
  double totalvalue,
) {
  return price + totalvalue;
}

double decrementtotal(
  double price,
  double totalvalue,
) {
  return totalvalue - price;
}

List<AvailabilityStruct>? initialAvailability() {
  final List<AvailabilityStruct> availability = [];

  final List<String> dayofweek = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday'
  ];

  for (final day in dayofweek) {
    availability.add(
        AvailabilityStruct(dayofweek: day, starttime: null, endtime: null));
  }
  return availability;
}

String generateOrderID() {
  DateTime now = DateTime.now();
  String timestamp = now.millisecondsSinceEpoch.toString();
  String randomCode = (1000 + (now.millisecondsSinceEpoch % 9000)).toString();
  return "ORD-$timestamp-$randomCode";
}

List<DateTime>? getAvailableSlots(
  String dateArg,
  List<AvailabilityStruct> availability,
) {
  DateTime parsedDate;
  try {
    parsedDate = DateFormat('yyyy-MM-dd').parse(dateArg);
  } catch (e) {
    return null; // Return null if the date format is incorrect
  }

  final matchingAvailability = availability.where((a) {
    return a.dayofweek.toLowerCase() ==
        DateFormat('EEEE').format(parsedDate).toLowerCase();
  }).toList();

  final availableSlots = <DateTime>[];

  for (final a in matchingAvailability) {
    if (a.hasStarttime() && a.hasEndtime()) {
      DateTime start = DateTime(parsedDate.year, parsedDate.month,
          parsedDate.day, a.starttime!.hour, a.starttime!.minute);
      DateTime end = DateTime(parsedDate.year, parsedDate.month, parsedDate.day,
          a.endtime!.hour, a.endtime!.minute);

      while (start.isBefore(end)) {
        availableSlots.add(start);
        start = start.add(Duration(hours: 2)); // Adjust duration as needed
      }
    }
  }

  DateTime now = DateTime.now();

  return availableSlots.where((slot) => slot.isAfter(now)).toList();
}

List<DateTime>? deliveryslots(
  String dateArg,
  List<AvailabilityStruct> availability,
) {
  // Try parsing the date argument
  DateTime parsedDate;
  try {
    parsedDate = DateFormat('yyyy-MM-dd').parse(dateArg);
  } catch (e) {
    return null; // Return null if the date format is incorrect
  }

  // Get current date and time
  DateTime now = DateTime.now();

  // Find availability matching the parsedDate's weekday
  final matchingAvailability = availability.where((a) {
    return a.dayofweek.toLowerCase() ==
        DateFormat('EEEE').format(parsedDate).toLowerCase();
  }).toList();

  // List to store available slots
  final List<DateTime> availableSlots = [];

  for (final a in matchingAvailability) {
    if (a.starttime != null && a.endtime != null) {
      DateTime start = DateTime(parsedDate.year, parsedDate.month,
          parsedDate.day, a.starttime!.hour, a.starttime!.minute);
      DateTime end = DateTime(parsedDate.year, parsedDate.month, parsedDate.day,
          a.endtime!.hour, a.endtime!.minute);

      // Generate slots with a 2-hour interval
      while (start.isBefore(end)) {
        if (start.isAfter(now)) {
          availableSlots.add(start);
        }
        start = start.add(Duration(hours: 2)); // Adjust duration if needed
      }
    }
  }

  return availableSlots.isEmpty ? null : availableSlots;
}

List<DateTime>? filterDeliverySlots(
  String pickupTime,
  List<AvailabilityStruct> deliverySlots,
) {
  List<DateTime> filteredSlots = [];

  try {
    // Convert the string pickup time into DateTime
    DateTime parsedPickupTime =
        DateFormat("EEEE, MMM d - h:mm a").parse(pickupTime);
    DateTime minDeliveryTime;

    if (parsedPickupTime.hour >= 12) {
      // Next day delivery (Starting from 8 AM next day)
      minDeliveryTime = DateTime(
        parsedPickupTime.year,
        parsedPickupTime.month,
        parsedPickupTime.day + 1, // Move to next day
        7, // Start from 8 AM
      );
    } else {
      // Delivery should be at least 8 hours after pickup time
      minDeliveryTime = parsedPickupTime.add(Duration(hours: 8));
    }

    // Extract available delivery slots from AvailabilityStruct and filter them
    filteredSlots = deliverySlots
        .where((slot) =>
            slot.hasStarttime() && // Ensure slot has a start time
            slot.starttime!
                .isAfter(minDeliveryTime)) // Compare with minDeliveryTime
        .map(
            (slot) => slot.starttime!) // Convert AvailabilityStruct to DateTime
        .toList();
  } catch (e) {
    print("Error parsing pickup time: $e");
  }

  return filteredSlots; // Return empty list if no slots are available
}

List<DateTime>? getAvailableDeliverySlots(
  String pickupDateTimeStr,
  List<AvailabilityStruct> deliveryAvailability,
) {
  DateTime pickupDateTime;

  // Parse the pickup date-time string
  try {
    pickupDateTime = DateFormat('HH:mm').parse(pickupDateTimeStr);
  } catch (e) {
    return null; // Return null if the date format is incorrect
  }

  // Define the minimum delivery time (8 hours after pickup)
  DateTime minDeliveryTime = pickupDateTime.add(Duration(hours: 8));

  // Find delivery slots that match the selected pickup day
  final matchingAvailability = deliveryAvailability.where((a) {
    return a.dayofweek.toLowerCase() ==
        DateFormat('EEEE').format(minDeliveryTime).toLowerCase();
  }).toList();

  final availableDeliverySlots = <DateTime>[];

  for (final a in matchingAvailability) {
    if (a.hasStarttime() && a.hasEndtime()) {
      DateTime start = DateTime(minDeliveryTime.year, minDeliveryTime.month,
          minDeliveryTime.day, a.starttime!.hour, a.starttime!.minute);
      DateTime end = DateTime(minDeliveryTime.year, minDeliveryTime.month,
          minDeliveryTime.day, a.endtime!.hour, a.endtime!.minute);

      while (start.isBefore(end)) {
        if (start.isAfter(minDeliveryTime)) {
          availableDeliverySlots.add(start);
        }
        start = start.add(Duration(hours: 2)); // Adjust duration as needed
      }
    }
  }

  DateTime now = DateTime.now();

  return availableDeliverySlots;
}

int incquantity(int quantity) {
  return quantity + 1;
}
