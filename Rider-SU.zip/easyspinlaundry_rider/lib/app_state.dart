import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<LatLng> _pickup = [LatLng(24.5886, 73.7022), LatLng(0, 0)];
  List<LatLng> get pickup => _pickup;
  set pickup(List<LatLng> value) {
    _pickup = value;
  }

  void addToPickup(LatLng value) {
    pickup.add(value);
  }

  void removeFromPickup(LatLng value) {
    pickup.remove(value);
  }

  void removeAtIndexFromPickup(int index) {
    pickup.removeAt(index);
  }

  void updatePickupAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    pickup[index] = updateFn(_pickup[index]);
  }

  void insertAtIndexInPickup(int index, LatLng value) {
    pickup.insert(index, value);
  }

  List<LatLng> _delivery = [LatLng(24.5976, 73.7454)];
  List<LatLng> get delivery => _delivery;
  set delivery(List<LatLng> value) {
    _delivery = value;
  }

  void addToDelivery(LatLng value) {
    delivery.add(value);
  }

  void removeFromDelivery(LatLng value) {
    delivery.remove(value);
  }

  void removeAtIndexFromDelivery(int index) {
    delivery.removeAt(index);
  }

  void updateDeliveryAtIndex(
    int index,
    LatLng Function(LatLng) updateFn,
  ) {
    delivery[index] = updateFn(_delivery[index]);
  }

  void insertAtIndexInDelivery(int index, LatLng value) {
    delivery.insert(index, value);
  }

  int _orderid = 123;
  int get orderid => _orderid;
  set orderid(int value) {
    _orderid = value;
  }

  List<String> _type = ['Rider', 'customer', 'center\n'];
  List<String> get type => _type;
  set type(List<String> value) {
    _type = value;
  }

  void addToType(String value) {
    type.add(value);
  }

  void removeFromType(String value) {
    type.remove(value);
  }

  void removeAtIndexFromType(int index) {
    type.removeAt(index);
  }

  void updateTypeAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    type[index] = updateFn(_type[index]);
  }

  void insertAtIndexInType(int index, String value) {
    type.insert(index, value);
  }

  int _inttt = 0;
  int get inttt => _inttt;
  set inttt(int value) {
    _inttt = value;
  }

  LatLng? _test = LatLng(24.5842953, 73.73155109999999);
  LatLng? get test => _test;
  set test(LatLng? value) {
    _test = value;
  }

  LatLng? _customerlatlong = LatLng(24.5976272, 73.7454473);
  LatLng? get customerlatlong => _customerlatlong;
  set customerlatlong(LatLng? value) {
    _customerlatlong = value;
  }

  LatLng? _centerlatlong = LatLng(24.5886328, 73.70218009999999);
  LatLng? get centerlatlong => _centerlatlong;
  set centerlatlong(LatLng? value) {
    _centerlatlong = value;
  }
}
