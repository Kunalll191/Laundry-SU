import '/flutter_flow/flutter_flow_util.dart';
import 'orderdetails_widget.dart' show OrderdetailsWidget;
import 'package:flutter/material.dart';

class OrderdetailsModel extends FlutterFlowModel<OrderdetailsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
