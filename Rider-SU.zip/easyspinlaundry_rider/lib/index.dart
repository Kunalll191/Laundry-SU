// Export pages
export '/pages/home_page/home_page_widget.dart' show HomePageWidget;
export '/login/login_widget.dart' show LoginWidget;
export '/onbording/onbording_widget.dart' show OnbordingWidget;
export '/approvalpage/approvalpage_widget.dart' show ApprovalpageWidget;
export '/order_req/order_req_widget.dart' show OrderReqWidget;
export '/profile/profile_widget.dart' show ProfileWidget;
export '/googlemap/googlemap_widget.dart' show GooglemapWidget;
export '/phone/phone_widget.dart' show PhoneWidget;
export '/orderdetails/orderdetails_widget.dart' show OrderdetailsWidget;
