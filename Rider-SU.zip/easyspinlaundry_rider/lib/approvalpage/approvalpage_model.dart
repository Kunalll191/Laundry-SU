import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'approvalpage_widget.dart' show ApprovalpageWidget;
import 'package:flutter/material.dart';

class ApprovalpageModel extends FlutterFlowModel<ApprovalpageWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
