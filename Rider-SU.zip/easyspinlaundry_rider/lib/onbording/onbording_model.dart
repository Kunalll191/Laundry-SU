import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'onbording_widget.dart' show OnbordingWidget;
import 'package:flutter/material.dart';

class OnbordingModel extends FlutterFlowModel<OnbordingWidget> {
  ///  State fields for stateful widgets in this page.

  // State field(s) for Fullname widget.
  FocusNode? fullnameFocusNode;
  TextEditingController? fullnameTextController;
  String? Function(BuildContext, String?)? fullnameTextControllerValidator;
  // State field(s) for address widget.
  FocusNode? addressFocusNode;
  TextEditingController? addressTextController;
  String? Function(BuildContext, String?)? addressTextControllerValidator;
  // State field(s) for pincode widget.
  FocusNode? pincodeFocusNode;
  TextEditingController? pincodeTextController;
  String? Function(BuildContext, String?)? pincodeTextControllerValidator;
  // State field(s) for adhar widget.
  FocusNode? adharFocusNode;
  TextEditingController? adharTextController;
  String? Function(BuildContext, String?)? adharTextControllerValidator;
  // State field(s) for pan widget.
  FocusNode? panFocusNode;
  TextEditingController? panTextController;
  String? Function(BuildContext, String?)? panTextControllerValidator;
  // State field(s) for dln widget.
  FocusNode? dlnFocusNode;
  TextEditingController? dlnTextController;
  String? Function(BuildContext, String?)? dlnTextControllerValidator;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    fullnameFocusNode?.dispose();
    fullnameTextController?.dispose();

    addressFocusNode?.dispose();
    addressTextController?.dispose();

    pincodeFocusNode?.dispose();
    pincodeTextController?.dispose();

    adharFocusNode?.dispose();
    adharTextController?.dispose();

    panFocusNode?.dispose();
    panTextController?.dispose();

    dlnFocusNode?.dispose();
    dlnTextController?.dispose();
  }
}
