import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class RideridRecord extends FirestoreRecord {
  RideridRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "pincode" field.
  int? _pincode;
  int get pincode => _pincode ?? 0;
  bool hasPincode() => _pincode != null;

  // "adharno" field.
  String? _adharno;
  String get adharno => _adharno ?? '';
  bool hasAdharno() => _adharno != null;

  // "panno" field.
  String? _panno;
  String get panno => _panno ?? '';
  bool hasPanno() => _panno != null;

  // "drivingno" field.
  String? _drivingno;
  String get drivingno => _drivingno ?? '';
  bool hasDrivingno() => _drivingno != null;

  // "approve" field.
  bool? _approve;
  bool get approve => _approve ?? false;
  bool hasApprove() => _approve != null;

  // "fcm_token" field.
  String? _fcmToken;
  String get fcmToken => _fcmToken ?? '';
  bool hasFcmToken() => _fcmToken != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "currentloc" field.
  LatLng? _currentloc;
  LatLng? get currentloc => _currentloc;
  bool hasCurrentloc() => _currentloc != null;

  // "lastupdated" field.
  DateTime? _lastupdated;
  DateTime? get lastupdated => _lastupdated;
  bool hasLastupdated() => _lastupdated != null;

  // "totalkm" field.
  int? _totalkm;
  int get totalkm => _totalkm ?? 0;
  bool hasTotalkm() => _totalkm != null;

  // "totalrides" field.
  double? _totalrides;
  double get totalrides => _totalrides ?? 0.0;
  bool hasTotalrides() => _totalrides != null;

  // "pickup" field.
  List<LatLng>? _pickup;
  List<LatLng> get pickup => _pickup ?? const [];
  bool hasPickup() => _pickup != null;

  // "delivery" field.
  List<LatLng>? _delivery;
  List<LatLng> get delivery => _delivery ?? const [];
  bool hasDelivery() => _delivery != null;

  // "addresss" field.
  LatLng? _addresss;
  LatLng? get addresss => _addresss;
  bool hasAddresss() => _addresss != null;

  // "currentorderid" field.
  String? _currentorderid;
  String get currentorderid => _currentorderid ?? '';
  bool hasCurrentorderid() => _currentorderid != null;

  // "totalride" field.
  double? _totalride;
  double get totalride => _totalride ?? 0.0;
  bool hasTotalride() => _totalride != null;

  // "ontheway" field.
  bool? _ontheway;
  bool get ontheway => _ontheway ?? false;
  bool hasOntheway() => _ontheway != null;

  // "online" field.
  bool? _online;
  bool get online => _online ?? false;
  bool hasOnline() => _online != null;

  // "avalable" field.
  bool? _avalable;
  bool get avalable => _avalable ?? false;
  bool hasAvalable() => _avalable != null;

  // "address" field.
  LatLng? _address;
  LatLng? get address => _address;
  bool hasAddress() => _address != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _pincode = castToType<int>(snapshotData['pincode']);
    _adharno = snapshotData['adharno'] as String?;
    _panno = snapshotData['panno'] as String?;
    _drivingno = snapshotData['drivingno'] as String?;
    _approve = snapshotData['approve'] as bool?;
    _fcmToken = snapshotData['fcm_token'] as String?;
    _status = snapshotData['status'] as String?;
    _currentloc = snapshotData['currentloc'] as LatLng?;
    _lastupdated = snapshotData['lastupdated'] as DateTime?;
    _totalkm = castToType<int>(snapshotData['totalkm']);
    _totalrides = castToType<double>(snapshotData['totalrides']);
    _pickup = getDataList(snapshotData['pickup']);
    _delivery = getDataList(snapshotData['delivery']);
    _addresss = snapshotData['addresss'] as LatLng?;
    _currentorderid = snapshotData['currentorderid'] as String?;
    _totalride = castToType<double>(snapshotData['totalride']);
    _ontheway = snapshotData['ontheway'] as bool?;
    _online = snapshotData['online'] as bool?;
    _avalable = snapshotData['avalable'] as bool?;
    _address = snapshotData['address'] as LatLng?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('riderid');

  static Stream<RideridRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => RideridRecord.fromSnapshot(s));

  static Future<RideridRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => RideridRecord.fromSnapshot(s));

  static RideridRecord fromSnapshot(DocumentSnapshot snapshot) =>
      RideridRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static RideridRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      RideridRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'RideridRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is RideridRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createRideridRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  int? pincode,
  String? adharno,
  String? panno,
  String? drivingno,
  bool? approve,
  String? fcmToken,
  String? status,
  LatLng? currentloc,
  DateTime? lastupdated,
  int? totalkm,
  double? totalrides,
  LatLng? addresss,
  String? currentorderid,
  double? totalride,
  bool? ontheway,
  bool? online,
  bool? avalable,
  LatLng? address,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'pincode': pincode,
      'adharno': adharno,
      'panno': panno,
      'drivingno': drivingno,
      'approve': approve,
      'fcm_token': fcmToken,
      'status': status,
      'currentloc': currentloc,
      'lastupdated': lastupdated,
      'totalkm': totalkm,
      'totalrides': totalrides,
      'addresss': addresss,
      'currentorderid': currentorderid,
      'totalride': totalride,
      'ontheway': ontheway,
      'online': online,
      'avalable': avalable,
      'address': address,
    }.withoutNulls,
  );

  return firestoreData;
}

class RideridRecordDocumentEquality implements Equality<RideridRecord> {
  const RideridRecordDocumentEquality();

  @override
  bool equals(RideridRecord? e1, RideridRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.pincode == e2?.pincode &&
        e1?.adharno == e2?.adharno &&
        e1?.panno == e2?.panno &&
        e1?.drivingno == e2?.drivingno &&
        e1?.approve == e2?.approve &&
        e1?.fcmToken == e2?.fcmToken &&
        e1?.status == e2?.status &&
        e1?.currentloc == e2?.currentloc &&
        e1?.lastupdated == e2?.lastupdated &&
        e1?.totalkm == e2?.totalkm &&
        e1?.totalrides == e2?.totalrides &&
        listEquality.equals(e1?.pickup, e2?.pickup) &&
        listEquality.equals(e1?.delivery, e2?.delivery) &&
        e1?.addresss == e2?.addresss &&
        e1?.currentorderid == e2?.currentorderid &&
        e1?.totalride == e2?.totalride &&
        e1?.ontheway == e2?.ontheway &&
        e1?.online == e2?.online &&
        e1?.avalable == e2?.avalable &&
        e1?.address == e2?.address;
  }

  @override
  int hash(RideridRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.pincode,
        e?.adharno,
        e?.panno,
        e?.drivingno,
        e?.approve,
        e?.fcmToken,
        e?.status,
        e?.currentloc,
        e?.lastupdated,
        e?.totalkm,
        e?.totalrides,
        e?.pickup,
        e?.delivery,
        e?.addresss,
        e?.currentorderid,
        e?.totalride,
        e?.ontheway,
        e?.online,
        e?.avalable,
        e?.address
      ]);

  @override
  bool isValidKey(Object? o) => o is RideridRecord;
}
