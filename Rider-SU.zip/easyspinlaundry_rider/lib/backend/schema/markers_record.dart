import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MarkersRecord extends FirestoreRecord {
  MarkersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "latitude" field.
  int? _latitude;
  int get latitude => _latitude ?? 0;
  bool hasLatitude() => _latitude != null;

  // "longitude" field.
  int? _longitude;
  int get longitude => _longitude ?? 0;
  bool hasLongitude() => _longitude != null;

  // "label" field.
  String? _label;
  String get label => _label ?? '';
  bool hasLabel() => _label != null;

  // "orderId" field.
  String? _orderId;
  String get orderId => _orderId ?? '';
  bool hasOrderId() => _orderId != null;

  // "riderId" field.
  String? _riderId;
  String get riderId => _riderId ?? '';
  bool hasRiderId() => _riderId != null;

  void _initializeFields() {
    _latitude = castToType<int>(snapshotData['latitude']);
    _longitude = castToType<int>(snapshotData['longitude']);
    _label = snapshotData['label'] as String?;
    _orderId = snapshotData['orderId'] as String?;
    _riderId = snapshotData['riderId'] as String?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('markers');

  static Stream<MarkersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MarkersRecord.fromSnapshot(s));

  static Future<MarkersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => MarkersRecord.fromSnapshot(s));

  static MarkersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MarkersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MarkersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MarkersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MarkersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MarkersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMarkersRecordData({
  int? latitude,
  int? longitude,
  String? label,
  String? orderId,
  String? riderId,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'latitude': latitude,
      'longitude': longitude,
      'label': label,
      'orderId': orderId,
      'riderId': riderId,
    }.withoutNulls,
  );

  return firestoreData;
}

class MarkersRecordDocumentEquality implements Equality<MarkersRecord> {
  const MarkersRecordDocumentEquality();

  @override
  bool equals(MarkersRecord? e1, MarkersRecord? e2) {
    return e1?.latitude == e2?.latitude &&
        e1?.longitude == e2?.longitude &&
        e1?.label == e2?.label &&
        e1?.orderId == e2?.orderId &&
        e1?.riderId == e2?.riderId;
  }

  @override
  int hash(MarkersRecord? e) => const ListEquality()
      .hash([e?.latitude, e?.longitude, e?.label, e?.orderId, e?.riderId]);

  @override
  bool isValidKey(Object? o) => o is MarkersRecord;
}
