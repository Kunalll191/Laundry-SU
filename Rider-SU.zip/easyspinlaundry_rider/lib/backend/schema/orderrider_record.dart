import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrderriderRecord extends FirestoreRecord {
  OrderriderRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "orderid" field.
  String? _orderid;
  String get orderid => _orderid ?? '';
  bool hasOrderid() => _orderid != null;

  // "totalamount" field.
  double? _totalamount;
  double get totalamount => _totalamount ?? 0.0;
  bool hasTotalamount() => _totalamount != null;

  // "paymentstatus" field.
  String? _paymentstatus;
  String get paymentstatus => _paymentstatus ?? '';
  bool hasPaymentstatus() => _paymentstatus != null;

  // "USERNAME" field.
  String? _username;
  String get username => _username ?? '';
  bool hasUsername() => _username != null;

  // "phoneno" field.
  String? _phoneno;
  String get phoneno => _phoneno ?? '';
  bool hasPhoneno() => _phoneno != null;

  // "pickuptime" field.
  DateTime? _pickuptime;
  DateTime? get pickuptime => _pickuptime;
  bool hasPickuptime() => _pickuptime != null;

  // "totalitem" field.
  int? _totalitem;
  int get totalitem => _totalitem ?? 0;
  bool hasTotalitem() => _totalitem != null;

  // "riderid" field.
  String? _riderid;
  String get riderid => _riderid ?? '';
  bool hasRiderid() => _riderid != null;

  // "centerid" field.
  String? _centerid;
  String get centerid => _centerid ?? '';
  bool hasCenterid() => _centerid != null;

  // "secondriderid" field.
  String? _secondriderid;
  String get secondriderid => _secondriderid ?? '';
  bool hasSecondriderid() => _secondriderid != null;

  // "customerid" field.
  String? _customerid;
  String get customerid => _customerid ?? '';
  bool hasCustomerid() => _customerid != null;

  // "fcm_tocken" field.
  String? _fcmTocken;
  String get fcmTocken => _fcmTocken ?? '';
  bool hasFcmTocken() => _fcmTocken != null;

  // "customerno" field.
  String? _customerno;
  String get customerno => _customerno ?? '';
  bool hasCustomerno() => _customerno != null;

  // "pickuploc" field.
  List<LatLng>? _pickuploc;
  List<LatLng> get pickuploc => _pickuploc ?? const [];
  bool hasPickuploc() => _pickuploc != null;

  // "deliverloc" field.
  List<LatLng>? _deliverloc;
  List<LatLng> get deliverloc => _deliverloc ?? const [];
  bool hasDeliverloc() => _deliverloc != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "deliverytime" field.
  DateTime? _deliverytime;
  DateTime? get deliverytime => _deliverytime;
  bool hasDeliverytime() => _deliverytime != null;

  // "riderAssigned" field.
  String? _riderAssigned;
  String get riderAssigned => _riderAssigned ?? '';
  bool hasRiderAssigned() => _riderAssigned != null;

  void _initializeFields() {
    _orderid = snapshotData['orderid'] as String?;
    _totalamount = castToType<double>(snapshotData['totalamount']);
    _paymentstatus = snapshotData['paymentstatus'] as String?;
    _username = snapshotData['USERNAME'] as String?;
    _phoneno = snapshotData['phoneno'] as String?;
    _pickuptime = snapshotData['pickuptime'] as DateTime?;
    _totalitem = castToType<int>(snapshotData['totalitem']);
    _riderid = snapshotData['riderid'] as String?;
    _centerid = snapshotData['centerid'] as String?;
    _secondriderid = snapshotData['secondriderid'] as String?;
    _customerid = snapshotData['customerid'] as String?;
    _fcmTocken = snapshotData['fcm_tocken'] as String?;
    _customerno = snapshotData['customerno'] as String?;
    _pickuploc = getDataList(snapshotData['pickuploc']);
    _deliverloc = getDataList(snapshotData['deliverloc']);
    _status = snapshotData['status'] as String?;
    _deliverytime = snapshotData['deliverytime'] as DateTime?;
    _riderAssigned = snapshotData['riderAssigned'] as String?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('orderrider');

  static Stream<OrderriderRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrderriderRecord.fromSnapshot(s));

  static Future<OrderriderRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrderriderRecord.fromSnapshot(s));

  static OrderriderRecord fromSnapshot(DocumentSnapshot snapshot) =>
      OrderriderRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrderriderRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrderriderRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrderriderRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrderriderRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrderriderRecordData({
  String? orderid,
  double? totalamount,
  String? paymentstatus,
  String? username,
  String? phoneno,
  DateTime? pickuptime,
  int? totalitem,
  String? riderid,
  String? centerid,
  String? secondriderid,
  String? customerid,
  String? fcmTocken,
  String? customerno,
  String? status,
  DateTime? deliverytime,
  String? riderAssigned,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'orderid': orderid,
      'totalamount': totalamount,
      'paymentstatus': paymentstatus,
      'USERNAME': username,
      'phoneno': phoneno,
      'pickuptime': pickuptime,
      'totalitem': totalitem,
      'riderid': riderid,
      'centerid': centerid,
      'secondriderid': secondriderid,
      'customerid': customerid,
      'fcm_tocken': fcmTocken,
      'customerno': customerno,
      'status': status,
      'deliverytime': deliverytime,
      'riderAssigned': riderAssigned,
    }.withoutNulls,
  );

  return firestoreData;
}

class OrderriderRecordDocumentEquality implements Equality<OrderriderRecord> {
  const OrderriderRecordDocumentEquality();

  @override
  bool equals(OrderriderRecord? e1, OrderriderRecord? e2) {
    const listEquality = ListEquality();
    return e1?.orderid == e2?.orderid &&
        e1?.totalamount == e2?.totalamount &&
        e1?.paymentstatus == e2?.paymentstatus &&
        e1?.username == e2?.username &&
        e1?.phoneno == e2?.phoneno &&
        e1?.pickuptime == e2?.pickuptime &&
        e1?.totalitem == e2?.totalitem &&
        e1?.riderid == e2?.riderid &&
        e1?.centerid == e2?.centerid &&
        e1?.secondriderid == e2?.secondriderid &&
        e1?.customerid == e2?.customerid &&
        e1?.fcmTocken == e2?.fcmTocken &&
        e1?.customerno == e2?.customerno &&
        listEquality.equals(e1?.pickuploc, e2?.pickuploc) &&
        listEquality.equals(e1?.deliverloc, e2?.deliverloc) &&
        e1?.status == e2?.status &&
        e1?.deliverytime == e2?.deliverytime &&
        e1?.riderAssigned == e2?.riderAssigned;
  }

  @override
  int hash(OrderriderRecord? e) => const ListEquality().hash([
        e?.orderid,
        e?.totalamount,
        e?.paymentstatus,
        e?.username,
        e?.phoneno,
        e?.pickuptime,
        e?.totalitem,
        e?.riderid,
        e?.centerid,
        e?.secondriderid,
        e?.customerid,
        e?.fcmTocken,
        e?.customerno,
        e?.pickuploc,
        e?.deliverloc,
        e?.status,
        e?.deliverytime,
        e?.riderAssigned
      ]);

  @override
  bool isValidKey(Object? o) => o is OrderriderRecord;
}
