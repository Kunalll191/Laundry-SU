import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class OrdersRecord extends FirestoreRecord {
  OrdersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "orderid" field.
  String? _orderid;
  String get orderid => _orderid ?? '';
  bool hasOrderid() => _orderid != null;

  // "totalamount" field.
  String? _totalamount;
  String get totalamount => _totalamount ?? '';
  bool hasTotalamount() => _totalamount != null;

  // "centerAssigned" field.
  String? _centerAssigned;
  String get centerAssigned => _centerAssigned ?? '';
  bool hasCenterAssigned() => _centerAssigned != null;

  // "deliveryTime" field.
  DateTime? _deliveryTime;
  DateTime? get deliveryTime => _deliveryTime;
  bool hasDeliveryTime() => _deliveryTime != null;

  // "pickupTime" field.
  DateTime? _pickupTime;
  DateTime? get pickupTime => _pickupTime;
  bool hasPickupTime() => _pickupTime != null;

  // "paymentstatus" field.
  String? _paymentstatus;
  String get paymentstatus => _paymentstatus ?? '';
  bool hasPaymentstatus() => _paymentstatus != null;

  // "serviceType" field.
  String? _serviceType;
  String get serviceType => _serviceType ?? '';
  bool hasServiceType() => _serviceType != null;

  // "riderlat" field.
  double? _riderlat;
  double get riderlat => _riderlat ?? 0.0;
  bool hasRiderlat() => _riderlat != null;

  // "riderlong" field.
  double? _riderlong;
  double get riderlong => _riderlong ?? 0.0;
  bool hasRiderlong() => _riderlong != null;

  // "customerLon" field.
  double? _customerLon;
  double get customerLon => _customerLon ?? 0.0;
  bool hasCustomerLon() => _customerLon != null;

  // "customerLat" field.
  double? _customerLat;
  double get customerLat => _customerLat ?? 0.0;
  bool hasCustomerLat() => _customerLat != null;

  // "centerlat" field.
  double? _centerlat;
  double get centerlat => _centerlat ?? 0.0;
  bool hasCenterlat() => _centerlat != null;

  // "centelong" field.
  double? _centelong;
  double get centelong => _centelong ?? 0.0;
  bool hasCentelong() => _centelong != null;

  // "TotalItems" field.
  int? _totalItems;
  int get totalItems => _totalItems ?? 0;
  bool hasTotalItems() => _totalItems != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "phonenumber" field.
  String? _phonenumber;
  String get phonenumber => _phonenumber ?? '';
  bool hasPhonenumber() => _phonenumber != null;

  void _initializeFields() {
    _orderid = snapshotData['orderid'] as String?;
    _totalamount = snapshotData['totalamount'] as String?;
    _centerAssigned = snapshotData['centerAssigned'] as String?;
    _deliveryTime = snapshotData['deliveryTime'] as DateTime?;
    _pickupTime = snapshotData['pickupTime'] as DateTime?;
    _paymentstatus = snapshotData['paymentstatus'] as String?;
    _serviceType = snapshotData['serviceType'] as String?;
    _riderlat = castToType<double>(snapshotData['riderlat']);
    _riderlong = castToType<double>(snapshotData['riderlong']);
    _customerLon = castToType<double>(snapshotData['customerLon']);
    _customerLat = castToType<double>(snapshotData['customerLat']);
    _centerlat = castToType<double>(snapshotData['centerlat']);
    _centelong = castToType<double>(snapshotData['centelong']);
    _totalItems = castToType<int>(snapshotData['TotalItems']);
    _name = snapshotData['name'] as String?;
    _phonenumber = snapshotData['phonenumber'] as String?;
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('orders');

  static Stream<OrdersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => OrdersRecord.fromSnapshot(s));

  static Future<OrdersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => OrdersRecord.fromSnapshot(s));

  static OrdersRecord fromSnapshot(DocumentSnapshot snapshot) => OrdersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static OrdersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      OrdersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'OrdersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is OrdersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createOrdersRecordData({
  String? orderid,
  String? totalamount,
  String? centerAssigned,
  DateTime? deliveryTime,
  DateTime? pickupTime,
  String? paymentstatus,
  String? serviceType,
  double? riderlat,
  double? riderlong,
  double? customerLon,
  double? customerLat,
  double? centerlat,
  double? centelong,
  int? totalItems,
  String? name,
  String? phonenumber,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'orderid': orderid,
      'totalamount': totalamount,
      'centerAssigned': centerAssigned,
      'deliveryTime': deliveryTime,
      'pickupTime': pickupTime,
      'paymentstatus': paymentstatus,
      'serviceType': serviceType,
      'riderlat': riderlat,
      'riderlong': riderlong,
      'customerLon': customerLon,
      'customerLat': customerLat,
      'centerlat': centerlat,
      'centelong': centelong,
      'TotalItems': totalItems,
      'name': name,
      'phonenumber': phonenumber,
    }.withoutNulls,
  );

  return firestoreData;
}

class OrdersRecordDocumentEquality implements Equality<OrdersRecord> {
  const OrdersRecordDocumentEquality();

  @override
  bool equals(OrdersRecord? e1, OrdersRecord? e2) {
    return e1?.orderid == e2?.orderid &&
        e1?.totalamount == e2?.totalamount &&
        e1?.centerAssigned == e2?.centerAssigned &&
        e1?.deliveryTime == e2?.deliveryTime &&
        e1?.pickupTime == e2?.pickupTime &&
        e1?.paymentstatus == e2?.paymentstatus &&
        e1?.serviceType == e2?.serviceType &&
        e1?.riderlat == e2?.riderlat &&
        e1?.riderlong == e2?.riderlong &&
        e1?.customerLon == e2?.customerLon &&
        e1?.customerLat == e2?.customerLat &&
        e1?.centerlat == e2?.centerlat &&
        e1?.centelong == e2?.centelong &&
        e1?.totalItems == e2?.totalItems &&
        e1?.name == e2?.name &&
        e1?.phonenumber == e2?.phonenumber;
  }

  @override
  int hash(OrdersRecord? e) => const ListEquality().hash([
        e?.orderid,
        e?.totalamount,
        e?.centerAssigned,
        e?.deliveryTime,
        e?.pickupTime,
        e?.paymentstatus,
        e?.serviceType,
        e?.riderlat,
        e?.riderlong,
        e?.customerLon,
        e?.customerLat,
        e?.centerlat,
        e?.centelong,
        e?.totalItems,
        e?.name,
        e?.phonenumber
      ]);

  @override
  bool isValidKey(Object? o) => o is OrdersRecord;
}
