import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class MarkersAndRoutesRecord extends FirestoreRecord {
  MarkersAndRoutesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  bool hasId() => _id != null;

  // "lat" field.
  double? _lat;
  double get lat => _lat ?? 0.0;
  bool hasLat() => _lat != null;

  // "lng" field.
  double? _lng;
  double get lng => _lng ?? 0.0;
  bool hasLng() => _lng != null;

  void _initializeFields() {
    _id = snapshotData['id'] as String?;
    _lat = castToType<double>(snapshotData['lat']);
    _lng = castToType<double>(snapshotData['lng']);
  }

  static CollectionReference get collection => FirebaseFirestore.instanceFor(
          app: Firebase.app(), databaseId: '(default)')
      .collection('MarkersAndRoutes');

  static Stream<MarkersAndRoutesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => MarkersAndRoutesRecord.fromSnapshot(s));

  static Future<MarkersAndRoutesRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => MarkersAndRoutesRecord.fromSnapshot(s));

  static MarkersAndRoutesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      MarkersAndRoutesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static MarkersAndRoutesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      MarkersAndRoutesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'MarkersAndRoutesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is MarkersAndRoutesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createMarkersAndRoutesRecordData({
  String? id,
  double? lat,
  double? lng,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'id': id,
      'lat': lat,
      'lng': lng,
    }.withoutNulls,
  );

  return firestoreData;
}

class MarkersAndRoutesRecordDocumentEquality
    implements Equality<MarkersAndRoutesRecord> {
  const MarkersAndRoutesRecordDocumentEquality();

  @override
  bool equals(MarkersAndRoutesRecord? e1, MarkersAndRoutesRecord? e2) {
    return e1?.id == e2?.id && e1?.lat == e2?.lat && e1?.lng == e2?.lng;
  }

  @override
  int hash(MarkersAndRoutesRecord? e) =>
      const ListEquality().hash([e?.id, e?.lat, e?.lng]);

  @override
  bool isValidKey(Object? o) => o is MarkersAndRoutesRecord;
}
