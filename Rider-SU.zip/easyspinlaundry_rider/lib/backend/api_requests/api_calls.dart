import 'dart:convert';
import 'package:flutter/foundation.dart';

import '/flutter_flow/flutter_flow_util.dart';
import 'api_manager.dart';

export 'api_manager.dart' show ApiCallResponse;

const _kPrivateApiFunctionName = 'ffPrivateApiCall';

class GetCoordinatesCall {
  static Future<ApiCallResponse> call({
    String? address = '',
    String? origin = '',
    String? destination = '',
  }) async {
    return ApiManager.instance.makeApiCall(
      callName: 'getCoordinates',
      apiUrl:
          'https://maps.googleapis.com/maps/api/directions/json?origin=New+Delhi,India&destination=Mumbai,India&mode=driving&key=AIzaSyB7j_VeeVJ-DPf5jT--Ch5jS_h8vcnMbyo',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'address': "INDIA",
        'key': "AIzaSyDSQOs9qQIx-pWlBimtJY4xRQenlxEJBIQ",
        'pickup': origin,
        'delivery': destination,
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class DirectionCall {
  static Future<ApiCallResponse> call({
    List<double>? originList,
    List<double>? destinationList,
  }) async {
    final origin = _serializeList(originList);
    final destination = _serializeList(destinationList);

    return ApiManager.instance.makeApiCall(
      callName: 'direction',
      apiUrl: 'https://maps.googleapis.com/maps/api/directions/json?',
      callType: ApiCallType.GET,
      headers: {},
      params: {
        'origin': origin,
        'destination': destination,
        'key': "AIzaSyB7j_VeeVJ-DPf5jT--Ch5jS_h8vcnMbyo",
      },
      returnBody: true,
      encodeBodyUtf8: false,
      decodeUtf8: false,
      cache: false,
      isStreamingApi: false,
      alwaysAllowBody: false,
    );
  }
}

class ApiPagingParams {
  int nextPageNumber = 0;
  int numItems = 0;
  dynamic lastResponse;

  ApiPagingParams({
    required this.nextPageNumber,
    required this.numItems,
    required this.lastResponse,
  });

  @override
  String toString() =>
      'PagingParams(nextPageNumber: $nextPageNumber, numItems: $numItems, lastResponse: $lastResponse,)';
}

String _toEncodable(dynamic item) {
  if (item is DocumentReference) {
    return item.path;
  }
  return item;
}

String _serializeList(List? list) {
  list ??= <String>[];
  try {
    return json.encode(list, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("List serialization failed. Returning empty list.");
    }
    return '[]';
  }
}

String _serializeJson(dynamic jsonVar, [bool isList = false]) {
  jsonVar ??= (isList ? [] : {});
  try {
    return json.encode(jsonVar, toEncodable: _toEncodable);
  } catch (_) {
    if (kDebugMode) {
      print("Json serialization failed. Returning empty json.");
    }
    return isList ? '[]' : '{}';
  }
}
