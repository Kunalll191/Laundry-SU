import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCafSusQGeKBlrFMDNvyR1RDnYH83Y6lVM",
            authDomain: "esayspinlaundry-dev.firebaseapp.com",
            projectId: "esayspinlaundry-dev",
            storageBucket: "esayspinlaundry-dev.firebasestorage.app",
            messagingSenderId: "463081420484",
            appId: "1:463081420484:web:ecbb033c7cb9f0b17f7b91"));
  } else {
    await Firebase.initializeApp();
  }
}
