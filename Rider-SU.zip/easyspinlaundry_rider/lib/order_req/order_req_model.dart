import '/flutter_flow/flutter_flow_util.dart';
import 'order_req_widget.dart' show OrderReqWidget;
import 'package:flutter/material.dart';

class OrderReqModel extends FlutterFlowModel<OrderReqWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
