import '/flutter_flow/flutter_flow_util.dart';
import 'googlemap_widget.dart' show GooglemapWidget;
import 'package:flutter/material.dart';

class GooglemapModel extends FlutterFlowModel<GooglemapWidget> {
  ///  Local state fields for this page.

  List<LatLng> polylineCoordinates = [];
  void addToPolylineCoordinates(LatLng item) => polylineCoordinates.add(item);
  void removeFromPolylineCoordinates(LatLng item) =>
      polylineCoordinates.remove(item);
  void removeAtIndexFromPolylineCoordinates(int index) =>
      polylineCoordinates.removeAt(index);
  void insertAtIndexInPolylineCoordinates(int index, LatLng item) =>
      polylineCoordinates.insert(index, item);
  void updatePolylineCoordinatesAtIndex(int index, Function(LatLng) updateFn) =>
      polylineCoordinates[index] = updateFn(polylineCoordinates[index]);

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
