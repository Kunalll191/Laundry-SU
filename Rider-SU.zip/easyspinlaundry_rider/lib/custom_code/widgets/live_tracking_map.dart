// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:google_maps_flutter/google_maps_flutter.dart' as gmaps;
import 'dart:async';
import 'package:location/location.dart' as loc;
import 'package:flutter/foundation.dart' show kIsWeb; // Check if running on web

class LiveTrackingMap extends StatefulWidget {
  final double? width;
  final double? height;
  final double? riderLat;
  final double? riderLng;
  final double? customerLat;
  final double? customerLng;
  final double? centerLat;
  final double? centerLng;

  const LiveTrackingMap({
    Key? key,
    this.width,
    this.height,
    this.riderLat,
    this.riderLng,
    this.customerLat,
    this.customerLng,
    this.centerLat,
    this.centerLng,
  }) : super(key: key);

  @override
  _LiveTrackingMapState createState() => _LiveTrackingMapState();
}

class _LiveTrackingMapState extends State<LiveTrackingMap> {
  Completer<gmaps.GoogleMapController> _controller = Completer();
  gmaps.LatLng? _riderPosition;
  StreamSubscription<loc.LocationData>? _locationSubscription;
  Set<gmaps.Marker> _markers = {};
  Set<gmaps.Polyline> _polylines = {};

  @override
  void initState() {
    super.initState();

    // Check if rider position is available
    if (widget.riderLat == null || widget.riderLng == null) {
      debugPrint('Error: Rider position is null.');
      return;
    }

    _riderPosition = gmaps.LatLng(widget.riderLat!, widget.riderLng!);

    // Only start live tracking if NOT running on web
    if (!kIsWeb) {
      _startLocationUpdates();
    }

    _updateMarkersAndPolylines();
  }

  void _startLocationUpdates() {
    loc.Location location = loc.Location();

    _locationSubscription = location.onLocationChanged.listen(
      (loc.LocationData? currentLocation) {
        if (currentLocation != null &&
            currentLocation.latitude != null &&
            currentLocation.longitude != null) {
          setState(() {
            _riderPosition = gmaps.LatLng(
                currentLocation.latitude!, currentLocation.longitude!);
            _updateMarkersAndPolylines();
          });

          _moveCamera(_riderPosition!);
        }
      },
    );
  }

  void _moveCamera(gmaps.LatLng target) async {
    if (_controller.isCompleted) {
      final gmaps.GoogleMapController controller = await _controller.future;
      controller.animateCamera(gmaps.CameraUpdate.newLatLng(target));
    }
  }

  void _updateMarkersAndPolylines() {
    if (_riderPosition == null) return;

    // Clear markers and polylines before adding new ones
    _markers.clear();
    _polylines.clear();

    _markers.add(
      gmaps.Marker(
        markerId: const gmaps.MarkerId('rider'),
        position: _riderPosition!,
        icon: gmaps.BitmapDescriptor.defaultMarkerWithHue(
            gmaps.BitmapDescriptor.hueBlue),
      ),
    );

    if (widget.customerLat != null && widget.customerLng != null) {
      _markers.add(
        gmaps.Marker(
          markerId: const gmaps.MarkerId('customer'),
          position: gmaps.LatLng(widget.customerLat!, widget.customerLng!),
          icon: gmaps.BitmapDescriptor.defaultMarkerWithHue(
              gmaps.BitmapDescriptor.hueGreen),
        ),
      );
    }

    if (widget.centerLat != null && widget.centerLng != null) {
      _markers.add(
        gmaps.Marker(
          markerId: const gmaps.MarkerId('center'),
          position: gmaps.LatLng(widget.centerLat!, widget.centerLng!),
          icon: gmaps.BitmapDescriptor.defaultMarkerWithHue(
              gmaps.BitmapDescriptor.hueRed),
        ),
      );
    }

    // Prevent polyline errors by ensuring at least 2 points
    List<gmaps.LatLng> polylinePoints = [];
    polylinePoints.add(_riderPosition!);

    if (widget.customerLat != null && widget.customerLng != null) {
      polylinePoints
          .add(gmaps.LatLng(widget.customerLat!, widget.customerLng!));
    }

    if (widget.centerLat != null && widget.centerLng != null) {
      polylinePoints.add(gmaps.LatLng(widget.centerLat!, widget.centerLng!));
    }

    if (polylinePoints.length > 1) {
      _polylines.add(
        gmaps.Polyline(
          polylineId: const gmaps.PolylineId('route'),
          color: Colors.blue,
          width: 5,
          points: polylinePoints,
        ),
      );
    }

    setState(() {});
  }

  @override
  void dispose() {
    _locationSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Handle Web Preview in FlutterFlow
    if (kIsWeb) {
      return const Center(
        child: Text(
          'Google Maps is not fully supported in Web Preview.',
          style: TextStyle(color: Colors.red),
        ),
      );
    }

    return SizedBox(
      width: widget.width ?? double.infinity,
      height: widget.height ?? 300,
      child: gmaps.GoogleMap(
        initialCameraPosition: gmaps.CameraPosition(
          target: _riderPosition ?? gmaps.LatLng(0, 0),
          zoom: 14,
        ),
        markers: _markers,
        polylines: _polylines,
        onMapCreated: (gmaps.GoogleMapController controller) {
          if (!_controller.isCompleted) {
            _controller.complete(controller);
          }
        },
      ),
    );
  }
}
