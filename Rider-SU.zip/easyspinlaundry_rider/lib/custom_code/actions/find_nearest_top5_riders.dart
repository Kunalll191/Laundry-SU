// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:math';

Future<List<String>> findNearestTop5Riders(
  double customerLat,
  double customerLng,
) async {
  try {
    // Query for riders who are online and available.
    final ridersQuery = await FirebaseFirestore.instance
        .collection('riderid')
        .where('online', isEqualTo: true)
        .where('available', isEqualTo: true)
        .get();

    if (ridersQuery.docs.isEmpty) {
      print("No online and available riders found.");
      return []; // Return an empty list if no riders are found.
    }

    // Calculate distances and store rider IDs and distances.
    List<Map<String, dynamic>> riderDistances = [];
    for (var doc in ridersQuery.docs) {
      final riderData = doc.data();
      final riderLat = riderData['latitude'] as double?;
      final riderLng = riderData['longitude'] as double?;

      // Skip if latitude or longitude is missing.
      if (riderLat == null || riderLng == null) {
        continue;
      }

      final distance = calculateDistance(
        customerLat,
        customerLng,
        riderLat,
        riderLng,
      );

      riderDistances.add({
        'riderId': doc.id,
        'distance': distance,
      });
    }

    // Sort riders by distance.
    riderDistances.sort((a, b) => a['distance'].compareTo(b['distance']));

    // Get the top 5 nearest rider IDs.
    List<String> nearestRiderIds = riderDistances
        .take(5)
        .map((rider) => rider['riderId'] as String)
        .toList();

    return nearestRiderIds;
  } catch (e) {
    print("Error finding nearest riders: $e");
    return []; // Return an empty list in case of errors.
  }
}

// Function to calculate distance (Haversine formula).
double calculateDistance(
  double lat1,
  double lon1,
  double lat2,
  double lon2,
) {
  const earthRadius = 6371; // Radius of the Earth in kilometers.

  final dLat = _degreesToRadians(lat2 - lat1);
  final dLon = _degreesToRadians(lon2 - lon1);

  final a = sin(dLat / 2) * sin(dLat / 2) +
      cos(_degreesToRadians(lat1)) *
          cos(_degreesToRadians(lat2)) *
          sin(dLon / 2) *
          sin(dLon / 2);

  final c = 2 * atan2(sqrt(a), sqrt(1 - a));

  final distance = earthRadius * c; // Distance in kilometers.
  return distance;
}

double _degreesToRadians(double degrees) {
  return degrees * (pi / 180);
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
