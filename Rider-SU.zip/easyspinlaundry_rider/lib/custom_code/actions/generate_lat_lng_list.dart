// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:google_maps_flutter/google_maps_flutter.dart'
    as google_maps; // Prefix for Google Maps LatLng
import '/flutter_flow/lat_lng.dart'
    as flutter_flow; // Prefix for FlutterFlow LatLng

List<flutter_flow.LatLng> generateLatLngList(
    List<double> latitudes, List<double> longitudes) {
  // Check that the latitude and longitude lists have the same lengt
  if (latitudes.length != longitudes.length) {
    throw ArgumentError(
        'Latitudes and longitudes lists must have the same length.');
  }

  // Create a list of FlutterFlow LatLng objects
  List<flutter_flow.LatLng> latLngList = [];

  // Loop through the latitudes and longitudes to create LatLng objects
  for (int i = 0; i < latitudes.length; i++) {
    latLngList.add(flutter_flow.LatLng(latitudes[i], longitudes[i]));
  }

  // Return the list of FlutterFlow LatLng objects
  return latLngList;
}
