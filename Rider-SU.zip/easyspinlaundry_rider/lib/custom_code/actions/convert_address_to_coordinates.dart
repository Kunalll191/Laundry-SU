// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:google_maps_flutter/google_maps_flutter.dart'
    as gmaps; // Alias Google Maps LatLng

Future<gmaps.LatLng?> convertAddressToCoordinates(String address) async {
  try {
    // Replace spaces with "+" for API compatibility
    String formattedAddress = address.replaceAll(' ', '+');

    // Your Google API Key (⚠️ Consider securing this API key)
    String apiKey = "AIzaSyB7j_VeeVJ-DPf5jT--Ch5jS_h8vcnMbyo";

    // Google Geocoding API URL
    String url =
        "https://maps.googleapis.com/maps/api/geocode/json?address=$formattedAddress&key=$apiKey";

    // Send API request
    final response = await http.get(Uri.parse(url));

    if (response.statusCode == 200) {
      final data = json.decode(response.body);

      if (data["status"] == "OK") {
        // Extract Latitude & Longitude
        double lat = data["results"][0]["geometry"]["location"]["lat"];
        double lng = data["results"][0]["geometry"]["location"]["lng"];

        // Return as Google Maps LatLng
        return gmaps.LatLng(lat, lng);
      } else {
        print("Error: ${data["status"]}");
        return null;
      }
    } else {
      print("HTTP Error: ${response.statusCode}");
      return null;
    }
  } catch (e) {
    print("Exception: $e");
    return null;
  }
}
