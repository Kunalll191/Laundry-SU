package com.mycompany.easyspinlaundryrider

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
